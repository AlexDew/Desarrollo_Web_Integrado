package com.utp.proyecto.service;

import com.utp.proyecto.model.ServicioTuristico;
import com.utp.proyecto.repository.ServicioTuristicoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ServicioTuristicoServiceTest {
    @Mock
    private ServicioTuristicoRepository servicios;
    @InjectMocks
    private ServicioTuristicoService serviciosService;

    @Test
    void guardarServicio_asignaIdYValoresIniciales() {
        when(servicios.findAll()).thenReturn(List.of());
        ServicioTuristico nuevo = new ServicioTuristico();
        when(servicios.save(nuevo)).thenReturn(nuevo);

        ServicioTuristico resultado = serviciosService.guardarServicio(nuevo);

        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getAtenciones()).isZero();
        assertThat(resultado.getActivo()).isTrue();
        verify(servicios).save(nuevo);
    }
}
