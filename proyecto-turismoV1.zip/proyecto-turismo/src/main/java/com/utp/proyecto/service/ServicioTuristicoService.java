package com.utp.proyecto.service;

import com.utp.proyecto.model.ServicioTuristico;
import com.utp.proyecto.repository.ServicioTuristicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioTuristicoService {
    private final ServicioTuristicoRepository servicios;

    public ServicioTuristicoService(ServicioTuristicoRepository servicios) {
        this.servicios = servicios;
    }

    public List<ServicioTuristico> listarServicios() {
        return servicios.findAll().stream().filter(ServicioTuristico::getActivo).toList();
    }

    public ServicioTuristico buscarServicio(Long id) {
        return servicios.findById(id);
    }

    public List<ServicioTuristico> buscarServiciosPorTipo(String tipo) {
        return listarServicios().stream()
                .filter(servicio -> servicio.getTipo().equalsIgnoreCase(tipo))
                .toList();
    }

    public ServicioTuristico guardarServicio(ServicioTuristico servicio) {
        servicio.setId(siguienteId());
        servicio.setActivo(true);
        servicio.setAtenciones(0);
        servicio.setCalificacion(0.0);
        return servicios.save(servicio);
    }

    public ServicioTuristico actualizarServicio(Long id, ServicioTuristico datos) {
        ServicioTuristico servicio = buscarServicio(id);
        if (servicio == null) return null;
        servicio.setNombre(datos.getNombre());
        servicio.setTipo(datos.getTipo());
        servicio.setDescripcion(datos.getDescripcion());
        servicio.setHorarios(datos.getHorarios());
        servicio.setPrecio(datos.getPrecio());
        servicio.setRuta(datos.getRuta());
        servicio.setContacto(datos.getContacto());
        servicio.setAceptaReservas(datos.getAceptaReservas());
        servicio.setActivo(datos.getActivo() == null || datos.getActivo());
        return servicios.update(servicio);
    }

    public boolean eliminarServicio(Long id) {
        return servicios.deleteById(id);
    }

    public ServicioTuristico registrarAtencion(Long id) {
        ServicioTuristico servicio = buscarServicio(id);
        if (servicio == null) return null;
        servicio.setAtenciones(servicio.getAtenciones() + 1);
        return servicios.update(servicio);
    }

    private long siguienteId() {
        return servicios.findAll().stream()
                .mapToLong(ServicioTuristico::getId)
                .max()
                .orElse(0) + 1;
    }
}
