package com.utp.proyecto.controller;

import com.utp.proyecto.model.LugarTuristico;
import com.utp.proyecto.model.ServicioTuristico;
import com.utp.proyecto.service.LugarTuristicoService;
import com.utp.proyecto.service.ServicioTuristicoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/turista")
public class TuristaController {
    private final LugarTuristicoService lugares;
    private final ServicioTuristicoService servicios;

    public TuristaController(LugarTuristicoService lugares, ServicioTuristicoService servicios) {
        this.lugares = lugares;
        this.servicios = servicios;
    }

    @GetMapping("/lugares")
    public List<LugarTuristico> lugares(@RequestParam(required = false) String tipo) {
        return tipo == null ? lugares.listarLugares() : lugares.buscarLugaresPorTipo(tipo);
    }

    @GetMapping("/lugares/{id}")
    public ResponseEntity<LugarTuristico> lugar(@PathVariable Long id) {
        return ResponseEntity.ofNullable(lugares.buscarLugar(id));
    }

    @PostMapping("/lugares/{id}/visitas")
    public ResponseEntity<LugarTuristico> registrarVisita(@PathVariable Long id) {
        return ResponseEntity.ofNullable(lugares.registrarVisita(id));
    }

    @GetMapping("/servicios")
    public List<ServicioTuristico> servicios(@RequestParam(required = false) String tipo) {
        return tipo == null ? servicios.listarServicios() : servicios.buscarServiciosPorTipo(tipo);
    }

    @PostMapping("/servicios/{id}/reservas")
    public ResponseEntity<ServicioTuristico> reservar(@PathVariable Long id) {
        return ResponseEntity.ofNullable(servicios.registrarAtencion(id));
    }
    
    @PatchMapping("/lugares/{id}/calificacion")
    public ResponseEntity<LugarTuristico> calificar(@PathVariable Long id, @RequestParam Double valor) {
        if (!lugares.calificarLugar(id, valor)) return ResponseEntity.badRequest().build();
        return ResponseEntity.ofNullable(lugares.buscarLugar(id));
    }
}
