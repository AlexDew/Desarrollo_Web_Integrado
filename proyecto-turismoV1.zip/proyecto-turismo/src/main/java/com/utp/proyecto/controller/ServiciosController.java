package com.utp.proyecto.controller;

import com.utp.proyecto.model.LugarTuristico;
import com.utp.proyecto.model.ServicioTuristico;
import com.utp.proyecto.service.LugarTuristicoService;
import com.utp.proyecto.service.ServicioTuristicoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/servicios")
public class ServiciosController {
    private final LugarTuristicoService lugares;
    private final ServicioTuristicoService servicios;

    public ServiciosController(LugarTuristicoService lugares, ServicioTuristicoService servicios) {
        this.lugares = lugares;
        this.servicios = servicios;
    }

    @PostMapping("/lugares")

    @ResponseStatus(HttpStatus.CREATED)

    public LugarTuristico registrarLugar(@RequestBody LugarTuristico lugar) { return lugares.guardarLugar(lugar); }

    @PutMapping("/lugares/{id}")
    public ResponseEntity<LugarTuristico> actualizarLugar(@PathVariable Long id, @RequestBody LugarTuristico lugar) {
        return ResponseEntity.ofNullable(lugares.actualizarLugar(id, lugar));
    }

    @DeleteMapping("/lugares/{id}")
    public ResponseEntity<Void> eliminarLugar(@PathVariable Long id) {
        return lugares.eliminarLugar(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ServicioTuristico registrarServicio(@RequestBody ServicioTuristico servicio) { return servicios.guardarServicio(servicio); }

    @PutMapping("/{id}")
    public ResponseEntity<ServicioTuristico> actualizarServicio(@PathVariable Long id, @RequestBody ServicioTuristico servicio) {
        return ResponseEntity.ofNullable(servicios.actualizarServicio(id, servicio));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarServicio(@PathVariable Long id) {
        return servicios.eliminarServicio(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @GetMapping
    public List<ServicioTuristico> listarServicios() { return servicios.listarServicios(); }

    @GetMapping("/estadisticas")
    public Object estadisticas() {
        return java.util.Map.of("lugaresRegistrados", lugares.listarLugares().size(),
                "serviciosRegistrados", servicios.listarServicios().size());
    }
}
