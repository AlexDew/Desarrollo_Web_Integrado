package com.utp.proyecto.service;

import com.utp.proyecto.model.LugarTuristico;
import com.utp.proyecto.repository.LugarTuristicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LugarTuristicoService {
    private final LugarTuristicoRepository lugares;

    public LugarTuristicoService(LugarTuristicoRepository lugares) {
        this.lugares = lugares;
    }

    public List<LugarTuristico> listarLugares() {
        return lugares.findAll().stream().filter(LugarTuristico::getActivo).toList();
    }

    public LugarTuristico buscarLugar(Long id) {
        return lugares.findById(id);
    }

    public List<LugarTuristico> buscarLugaresPorTipo(String tipo) {
        return listarLugares().stream()
                .filter(lugar -> lugar.getTipo().equalsIgnoreCase(tipo))
                .toList();
    }

    public LugarTuristico guardarLugar(LugarTuristico lugar) {
        lugar.setId(siguienteId());
        lugar.setActivo(true);
        lugar.setVisitantes(0);
        lugar.setCalificacion(0.0);
        return lugares.save(lugar);
    }

    public LugarTuristico actualizarLugar(Long id, LugarTuristico datos) {
        LugarTuristico lugar = buscarLugar(id);
        if (lugar == null) return null;
        lugar.setNombre(datos.getNombre());
        lugar.setTipo(datos.getTipo());
        lugar.setDescripcion(datos.getDescripcion());
        lugar.setDireccion(datos.getDireccion());
        lugar.setHorarios(datos.getHorarios());
        lugar.setContacto(datos.getContacto());
        lugar.setActivo(datos.getActivo() == null || datos.getActivo());
        return lugares.update(lugar);
    }

    public boolean eliminarLugar(Long id) {
        return lugares.deleteById(id);
    }

    public LugarTuristico registrarVisita(Long id) {
        LugarTuristico lugar = buscarLugar(id);
        if (lugar == null) return null;
        lugar.setVisitantes(lugar.getVisitantes() + 1);
        return lugares.update(lugar);
    }

    public boolean calificarLugar(Long id, Double calificacion) {
        LugarTuristico lugar = buscarLugar(id);
        if (lugar == null || calificacion == null || calificacion < 1 || calificacion > 5) {
            return false;
        }
        lugar.setCalificacion(calificacion);
        lugares.update(lugar);
        return true;
    }

    private long siguienteId() {
        return lugares.findAll().stream()
                .mapToLong(LugarTuristico::getId)
                .max()
                .orElse(0) + 1;
    }
}
